package com.beef.util.redis.junittest;

public class TestData1 {
	private String _item1 = "";
	private String _item2 = "";
	private long _item3 = 0;
	
	public String getItem1() {
		return _item1;
	}
	public void setItem1(String item1) {
		_item1 = item1;
	}
	public String getItem2() {
		return _item2;
	}
	public void setItem2(String item2) {
		_item2 = item2;
	}
	public long getItem3() {
		return _item3;
	}
	public void setItem3(long item3) {
		_item3 = item3;
	}
	
	
}
